//
//  文件名称：main.cpp
//  项目名称：C++编程实例
//  当前版本：1.0
//  Created by Frank on 2019/6/14.
//  Copyright © 2019 Frank. All rights reserved.
//

#include <iostream>
#include <ctime>
#include "Header.h"

using namespace std;

number s;

//随机产生数字
int number::setnum(){
    int num;
    srand(time(NULL));
    num=1+rand()%9999;
    return num;
}


//设置时间
void number::settime(){
    cout<<"请设置时间(单位s)"<<endl;
    cin>>t;
}


//选择开始游戏或是退出
void number:: choose(){
    
    cout<<"1.开始"<<endl<<"2.退出"<<endl<<"请选择："<<endl;
    cin>>m;
    
    if(m!=1&&m!=2){
        cout<<"抱歉，输入有误！"<<endl;
    }
    
    switch(m){
        case 1:s.play();
            break;
        case 2:s.quit();
            break;
        default:cout<<"抱歉，输入有误！"<<endl;
    }
}


//开始游戏
void number:: play(){
    s.settime();
    
    while(m==1){
        clock_t start,finish = 0;
        k=s.setnum();
        cout<<"请猜："<<endl;
        start=clock();
        
        while(cin>>a){
            if(a>k)
                cout<<"猜高了，请继续猜："<<endl;
            if(a<k)
                cout<<"猜低了，请继续猜："<<endl;
            if(a==k){
                flag=1;
                break;
            }
            finish=clock();
            if((finish-start)>=t*1000){
                flag=0;
                break;
            }
        }
        finish=clock();
        
        if(flag==1&&(finish-start)<t*1000){
            cout<<"恭喜！正确猜出数字"<<k<<endl;
            cout<<"1.继续"<<endl<<"2.退出"<<endl<<"请选择："<<endl;
            cin>>m;
        }
        else{
            cout<<"很遗憾你未能在规定时间内猜出数字"<<endl;
            cout<<"该数字为"<<k<<endl;
            cout<<"1.继续"<<endl<<"2.退出"<<endl<<"请选择："<<endl;
            cin>>m;
        }
    }
    
    if(m==2)
        s.quit();
}


//退出游戏
void number::quit(){
    cout<<"欢迎下次使用！"<<endl;
}


int main(){
    s.choose();
}
