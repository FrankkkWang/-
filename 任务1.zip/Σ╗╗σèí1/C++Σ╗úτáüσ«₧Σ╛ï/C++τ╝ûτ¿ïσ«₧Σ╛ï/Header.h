//
//  文件名称：Header.h
//  项目名称：C++编程实例
//  当前版本：1.0
//  Created by Frank on 2019/6/14.
//  Copyright © 2019 Frank. All rights reserved.
//

#ifndef Header_h
#define Header_h

class number{
private:
    double t;
    int m;
    int k;
    int a;
    int flag;
public:
    int setnum();
    void settime();
    void choose();
    void play();
    void quit();
};

#endif /* Header_h */
