/*
 Navicat Premium Data Transfer

 Source Server         : order
 Source Server Type    : MySQL
 Source Server Version : 80013
 Source Host           : localhost:3306
 Source Schema         : meal

 Target Server Type    : MySQL
 Target Server Version : 80013
 File Encoding         : 65001

 Date: 14/06/2019 14:03:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `goodsName` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `goodsDesc` varchar(255) DEFAULT NULL,
  `getImageLink` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for orderList
-- ----------------------------
DROP TABLE IF EXISTS `orderList`;
CREATE TABLE `orderList` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT NULL,
  `userAddress` varchar(255) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `totalCost` decimal(10,2) DEFAULT NULL,
  `goodsName0` varchar(255) DEFAULT NULL,
  `goodsNum0` varchar(255) DEFAULT NULL,
  `goodsPrice0` varchar(255) DEFAULT NULL,
  `goodsName1` varchar(255) DEFAULT NULL,
  `goodsNum1` varchar(255) DEFAULT NULL,
  `goodsPrice1` varchar(255) DEFAULT NULL,
  `goodsName2` varchar(255) DEFAULT NULL,
  `goodsNum2` varchar(255) DEFAULT NULL,
  `goodsPrice2` varchar(255) DEFAULT NULL,
  `goodsName3` varchar(255) DEFAULT NULL,
  `goodsNum3` varchar(255) DEFAULT NULL,
  `goodsPrice3` varchar(255) DEFAULT NULL,
  `goodsName4` varchar(255) DEFAULT NULL,
  `goodsNum4` varchar(255) DEFAULT NULL,
  `goodsPrice4` varchar(255) DEFAULT NULL,
  `goodsName5` varchar(255) DEFAULT NULL,
  `goodsNum5` varchar(255) DEFAULT NULL,
  `goodsPrice5` varchar(255) DEFAULT NULL,
  `ensure` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `userName` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `phoneNum` varchar(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `vip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

SET FOREIGN_KEY_CHECKS = 1;
