//author:赵季程

package com.view;

        import com.auxiliary.connectMySQL;
        import com.dao.orderDao;
        import com.dao.userDao;
        import com.model.Order;

        import javax.swing.*;
        import javax.swing.border.EtchedBorder;
        import java.awt.*;
        import java.awt.event.ActionEvent;
        import java.awt.event.ActionListener;
        import java.awt.geom.Ellipse2D;
        import java.sql.Connection;
        import java.sql.PreparedStatement;


public class checkOrderFrm extends JFrame implements ActionListener {

    com.auxiliary.connectMySQL connectMySQL = new connectMySQL();
    com.dao.userDao userDao = new userDao();
    com.dao.orderDao orderDao = new orderDao();

    //region 订单中的菜的信息
    public static class north extends JPanel {
        JLabel image = new JLabel("图片");
        JLabel dishName = new JLabel("名称:");
        JLabel price = new JLabel("价格:");
        JLabel number = new JLabel("数量:");
        public JLabel dishLabel = new JLabel("");
        public JLabel priceLabel = new JLabel("");


        orderRoundButton minus = new orderRoundButton("-"),
                and = new orderRoundButton("+");

        public JTextField numberText;

        Box north1Box,
                north2Box,
                northBox;

        JPanel buttonPanel,
                northxPanel;

        public north() {
            minus.setBackground(Color.YELLOW);
            and.setBackground(Color.YELLOW);
            numberText = new JTextField("0", 2);
            buttonPanel = new JPanel();
            buttonPanel.setLayout(new FlowLayout());
            buttonPanel.add(minus);
            buttonPanel.add(numberText);
            buttonPanel.add(and);
            north2Box = Box.createVerticalBox();
            north2Box.add(dishLabel);
            north2Box.add(Box.createVerticalStrut(8));
            north2Box.add(priceLabel);
            north2Box.add(Box.createVerticalStrut(8));
            north2Box.add(buttonPanel);
            north1Box = Box.createVerticalBox();
            north1Box.add(dishName);
            north1Box.add(Box.createVerticalStrut(8));
            north1Box.add(price);
            north1Box.add(Box.createVerticalStrut(8));
            north1Box.add(number);
            northBox = Box.createHorizontalBox();
            northBox.add(north1Box);
            northBox.add(Box.createHorizontalStrut(20));
            northBox.add(north2Box);
            northxPanel = new JPanel();
            northxPanel.setLayout(new FlowLayout());
            northxPanel.add(image);
            northxPanel.add(northBox);

            add(northxPanel);
            this.setBorder(new EtchedBorder(EtchedBorder.RAISED));
            this.setLayout(new FlowLayout());
            this.setVisible(true);
            this.validate();
        }
    }
    //endregion

    //region 订单
    JLabel consignee;//收货人标签
    JLabel shippingAddress;//收货地址标签
    public JLabel discount;//折扣信息标签
    JLabel total;//总价标签
    public JLabel discountLabel;//具体折扣信息
    public JLabel totalLabel;//具体总价

    JPanel centerPanel,//中间面板
            southPanel;//下端面板
    //菜品栏面板
    public north[] n = new north[6];

    Box baseBox,
            northxBox,
            center1Box,
            center2Box;

    JScrollPane pane;//滚动列表

    public JTextField textName;//收货人文本框
    public JTextField textAddress;//收货地址文本框
    JButton button;//确认按钮

    public checkOrderFrm(String s) {
        setTitle(s);
        //各个标签附初值
        consignee = new JLabel("收货人：");
        shippingAddress = new JLabel("收货地址:");
        discount = new JLabel("折扣：");
        total = new JLabel("总价：");
        discountLabel = new JLabel("无优惠");
        totalLabel = new JLabel("0");
        //设置图片


        //*****
        textName = new JTextField(12);
        textAddress = new JTextField(12);

        textName.setText(loginFrm.currentUser.getUserName());
        textAddress.setText(loginFrm.currentUser.getAddress());

        button = new JButton("确认");
        Container con = getContentPane();//提取面板容器
        //优惠取值

        if (loginFrm.currentUser.getVip().equals("是"))
            discountLabel.setText("八折优惠");


        //
        //最底端面板south绘制
        southPanel = new JPanel();
        southPanel.setSize(445, 59);
        southPanel.setLayout(new FlowLayout());
        southPanel.add(discount);
        southPanel.add(discountLabel);
        southPanel.add(button);
        southPanel.add(total);
        southPanel.add(totalLabel);
        //中部面板center绘制
        centerPanel = new JPanel();
        center1Box = Box.createVerticalBox();
        center1Box.add(consignee);
        center1Box.add(Box.createVerticalStrut(8));
        center1Box.add(shippingAddress);
        center2Box = Box.createVerticalBox();
        center2Box.add(textName);
        center2Box.add(Box.createVerticalStrut(8));
        center2Box.add(textAddress);
        centerPanel.setLayout(new FlowLayout());
        centerPanel.add(center1Box);
        centerPanel.add(center2Box);
        centerPanel.setBorder(new EtchedBorder(EtchedBorder.RAISED));
        //上部板的绘制

        for (int i = 0; i < 6; i++) {
            n[i] = new north();
        }

        northxBox = Box.createVerticalBox();
        northxBox.add(n[0]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[1]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[2]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[3]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[4]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[5]);

        pane = new JScrollPane(northxBox) {
            public Dimension getPreferredSize() {
                return new Dimension(445, 100);
            }
        };
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        baseBox = Box.createVerticalBox();
        baseBox.add(pane);
        baseBox.add(Box.createVerticalStrut(10));
        baseBox.add(centerPanel);
        baseBox.add(Box.createVerticalStrut(10));
        baseBox.add(southPanel);
        con.add(baseBox);
        con.setLayout(new FlowLayout());
        setSize(455, 300);
        button.addActionListener(this);
        for (int i = 0; i < 6; i++) {
            n[i].minus.addActionListener(this);
            n[i].and.addActionListener(this);
        }


        setVisible(true);
        validate();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    //endregion

    //region 按钮设置
    public static class orderRoundButton extends JButton {
        public orderRoundButton(String label) {
            super(label);
            Dimension size = new Dimension();
            size.width = size.height = 12;
            setPreferredSize(size);
            setContentAreaFilled(false);
        }

        protected void paintComponent(Graphics g) {
            if (getModel().isArmed()) {
                g.setColor(Color.blue);
            } else {
                g.setColor(getBackground());
            }
            g.fillOval(0, 0, getSize().width - 1, getSize().height - 1);
            super.paintComponent(g);
        }

        protected void paintBorder(Graphics g) {
            g.setColor(getForeground());
            g.drawOval(0, 0, getSize().width - 1, getSize().height - 1);
        }

        Shape shape;

        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new Ellipse2D.Float(0, 0, getWidth(), getHeight());
            }
            return shape.contains(x, y);
        }
    }
    //endregion

    //minus，and，确认,事件
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == n[0].minus) {
            int num = Integer.parseInt(n[0].numberText.getText());
            num--;
            n[0].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[0].and) {
            int num = Integer.parseInt(n[0].numberText.getText());
            num++;
            n[0].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[1].minus) {
            int num = Integer.parseInt(n[1].numberText.getText());
            num--;
            n[1].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[1].and) {
            int num = Integer.parseInt(n[1].numberText.getText());
            num++;
            n[1].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[2].minus) {
            int num = Integer.parseInt(n[2].numberText.getText());
            num--;
            n[2].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[2].and) {
            int num = Integer.parseInt(n[2].numberText.getText());
            num++;
            n[2].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[3].minus) {
            int num = Integer.parseInt(n[3].numberText.getText());
            num--;
            n[3].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[3].and) {
            int num = Integer.parseInt(n[3].numberText.getText());
            num++;
            n[3].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[4].minus) {
            int num = Integer.parseInt(n[4].numberText.getText());
            num--;
            n[4].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[4].and) {
            int num = Integer.parseInt(n[4].numberText.getText());
            num++;
            n[4].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[5].minus) {
            int num = Integer.parseInt(n[5].numberText.getText());
            num--;
            n[5].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[5].and) {
            int num = Integer.parseInt(n[5].numberText.getText());
            num++;
            n[5].numberText.setText(String.valueOf(num));
        }


        if (e.getSource() == button) {

            Connection con=null;
            con = connectMySQL.getCon();
            try {
                int result=orderDao.orderCheck(con);
                if(result==1)
                    JOptionPane.showMessageDialog(null, "已确认订单","提示",1);
            } catch (Exception e1) {
                e1.printStackTrace();
            }

            this.setVisible(false);

        }
    }

    public static void main (String args[]){
        checkOrderFrm win = new checkOrderFrm("新订单");
    }
}
