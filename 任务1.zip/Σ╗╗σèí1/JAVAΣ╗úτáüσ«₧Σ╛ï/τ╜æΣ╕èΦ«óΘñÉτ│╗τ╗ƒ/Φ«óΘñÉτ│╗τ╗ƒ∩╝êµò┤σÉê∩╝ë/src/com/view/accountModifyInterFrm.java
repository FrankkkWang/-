package com.view;

import java.sql.Connection;
import java.awt.event.*;

import javax.swing.*;

import com.dao.userDao;
import com.model.User;
import com.auxiliary.connectMySQL;

public class accountModifyInterFrm extends JFrame {

    //region 变量声明
    connectMySQL connectMySQL = new connectMySQL();
    userDao userDao = new userDao();

    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JButton jb_modify;
    private JButton jb_cancel;
    private JTextField addressTxt;
    private JTextField phoneNumTxt;
    private JTextField genderTxt;
    private JPasswordField newPasswordConfirmTxt;
    private JPasswordField newPasswordTxt;
    private JPasswordField oldPasswordTxt;
    private JTextField userNameTxt;
    //endregion

    //region 窗体位置
    public accountModifyInterFrm() {
        initComponents();
        this.setLocation(600, 150);
        this.userNameTxt.setText(loginFrm.currentUser.getUserName());
        this.genderTxt.setText(loginFrm.currentUser.getGender());
        this.phoneNumTxt.setText(loginFrm.currentUser.getPhoneNum());
        this.addressTxt.setText(loginFrm.currentUser.getAddress());
    }
    //endregion

    //region 组件布局
    private void initComponents() {

        //region 定义变量
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jLabel6 = new JLabel();
        jLabel7 = new JLabel();
        jb_modify = new JButton();
        jb_cancel = new JButton();
        userNameTxt = new JTextField();
        oldPasswordTxt = new JPasswordField();
        newPasswordTxt = new JPasswordField();
        newPasswordConfirmTxt = new JPasswordField();
        genderTxt = new JTextField();
        phoneNumTxt = new JTextField();
        addressTxt = new JTextField();
        //endregion

        //region 窗体设置
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("个人信息");
        //endregion

        //region文本输出设置及注册侦听函数
        jLabel1.setText("用户名：");
        jLabel2.setText("旧密码：");
        jLabel3.setText("新密码：");

        jLabel4.setText("确认密码：");

        jLabel5.setText("性别：");

        jLabel6.setText("手机号：");

        jLabel7.setText("收货地址：");

        //jb_modify.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/edit.png")));
        jb_modify.setText("修改");
        jb_modify.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jb_modifyActionPerformed(evt);
            }
        });

        //jb_cancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/reset.png")));
        jb_cancel.setText("取消");
        jb_cancel.addActionListener(new ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_cancelActionPerformed(evt);
            }
        });

        userNameTxt.setEnabled(false);
        //endregion


        //组件布局

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);

        //region 水平布局

        //确认键与取消键水平串行
        GroupLayout.SequentialGroup SG1=layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(jb_modify)
                .addGap(40, 40, 40)
                .addComponent(jb_cancel);
        //文本框水平平行
        GroupLayout.ParallelGroup PG1=layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
                .addComponent(addressTxt)
                .addComponent(phoneNumTxt)
                .addComponent(genderTxt)
                .addComponent(newPasswordConfirmTxt)
                .addComponent(newPasswordTxt)
                .addComponent(oldPasswordTxt)
                .addComponent(userNameTxt,GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE);

        //region 信息文本水平并行
        GroupLayout.ParallelGroup PG2=layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                .addComponent(jLabel1)
                .addComponent(jLabel2)
                .addComponent(jLabel3)
                .addComponent(jLabel4)
                .addComponent(jLabel5)
                .addComponent(jLabel6)
                .addComponent(jLabel7);
        //endregion

        //region 信息文本与文本框水平串行
        GroupLayout.SequentialGroup SG2=layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(PG2)
                .addGap(15, 15, 15)
                .addGroup(PG1);
        //endregion

        //region 文本，文本框与按键水平并行
        GroupLayout.ParallelGroup PG3=layout.createParallelGroup()
                .addGroup(SG2)
                .addGroup(SG1);
        //endregion

        //region 整体水平调整
        GroupLayout.ParallelGroup PG4=layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGroup(PG3)
                        .addGap(60, 60, 60));
        //endregion

        //水平设置
        layout.setHorizontalGroup(PG4);
        //endregion

        //region 竖直布局

        //按键竖直并行
        GroupLayout.ParallelGroup PG_1=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jb_modify)
                .addComponent(jb_cancel);
        GroupLayout.ParallelGroup PG_2=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel7)
                .addComponent(addressTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE);
        GroupLayout.ParallelGroup PG_3=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel6)
                .addComponent(phoneNumTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE);
        GroupLayout.ParallelGroup PG_4=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel5)
                .addComponent(genderTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE);
        GroupLayout.ParallelGroup PG_5=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel4)
                .addComponent(newPasswordConfirmTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE);
        GroupLayout.ParallelGroup PG_6=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel3)
                .addComponent(newPasswordTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE);
        GroupLayout.ParallelGroup PG_7=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel2)
                .addComponent(oldPasswordTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE);
        GroupLayout.ParallelGroup PG_8=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel1)
                .addComponent(userNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE);

        GroupLayout.SequentialGroup SG_1=layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(PG_8)
                .addGap(18, 18, 18)
                .addGroup(PG_7)
                .addGap(18, 18, 18)
                .addGroup(PG_6)
                .addGap(18, 18, 18)
                .addGroup(PG_5)
                .addGap(18, 18, 18)
                .addGroup(PG_4)
                .addGap(18, 18, 18)
                .addGroup(PG_3)
                .addGap(18, 18, 18)
                .addGroup(PG_2)
                .addGap(30, 30, 30)
                .addGroup(PG_1)
                .addGap(40, 40, 40);
        GroupLayout.ParallelGroup PG_9=layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(GroupLayout.Alignment.TRAILING, SG_1);

        layout.setVerticalGroup(PG_9);

        pack();
        //endregion
    }

    //endregion

    //region 修改响应函数
    private void jb_modifyActionPerformed(ActionEvent evt) {

        String oldPassword=new String(this.oldPasswordTxt.getPassword());
        String newPassword1=new String(this.newPasswordTxt.getPassword());
        String newPassword2=new String(this.newPasswordConfirmTxt.getPassword());
        String gender=new String(this.genderTxt.getText());
        String phoneNum=new String(this.phoneNumTxt.getText());
        String address=new String(this.addressTxt.getText());

        //新密码不能为空
        if (oldPassword.equals("")) {
            JOptionPane.showMessageDialog(null, "旧密码不能为空！");
            return;
        }

        //不能只填确认密码，不填新密码
        if (newPassword1.equals("")&&(!newPassword2.equals(""))) {
            JOptionPane.showMessageDialog(null, "新密码不能为空！");
            return;
        }
        if (newPassword2.equals("")&&(!newPassword1.equals(""))) {
            JOptionPane.showMessageDialog(null, "请确认新密码！");
            return;
        }
        if (!newPassword1.equals(newPassword2)) {
            JOptionPane.showMessageDialog(null, "两次输入的密码不一致！");
            return;
        }


        User user = null;
        Connection con = null;
        try {
            con = connectMySQL.getCon();
            user = new User(loginFrm.currentUser.getUserName(), oldPassword);

            //旧密码输对
            if (userDao.login(con, user) != null) {
                user.setId(loginFrm.currentUser.getId());

                //更新密码
                if(!newPassword1.equals(""))
                    user.setPassword(newPassword1);
                else
                    user.setPassword(loginFrm.currentUser.getPassword());

                //更新性别
                if(!gender.equals(""))
                    user.setGender(gender);
                else
                    user.setGender(loginFrm.currentUser.getGender());

                //更新手机号
                if (!phoneNum.equals(""))
                    user.setPhoneNum(phoneNum);
                else
                    user.setPhoneNum(loginFrm.currentUser.getPhoneNum());

                //更新地址
                if(!address.equals(""))
                    user.setAddress(address);
                else
                    user.setAddress(loginFrm.currentUser.getAddress());

                int modifyNum = userDao.userModify(con, user);
                if (1 == modifyNum) {//更新成功
                    JOptionPane.showMessageDialog(null, "修改成功！");
                    this.oldPasswordTxt.setText("");
                    this.newPasswordTxt.setText("");
                    this.newPasswordConfirmTxt.setText("");
                    this.genderTxt.setText("");
                    this.phoneNumTxt.setText("");
                    this.addressTxt.setText("");
                }
                else
                    JOptionPane.showMessageDialog(null, "修改失败，请重新输入");
            }
            else
                JOptionPane.showMessageDialog(null, "旧密码错误！请重新输入");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                connectMySQL.closeCon(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    //endregion

    //region 清除内容
    private void jb_cancelActionPerformed(java.awt.event.ActionEvent evt) {
        this.oldPasswordTxt.setText("");
        this.newPasswordTxt.setText("");
        this.newPasswordConfirmTxt.setText("");
        this.genderTxt.setText("");
        this.phoneNumTxt.setText("");
        this.addressTxt.setText("");
        this.setVisible(false);
    }
    //endregion


}