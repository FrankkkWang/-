
package com.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EtchedBorder;

import com.auxiliary.connectMySQL;
import com.dao.goodsDao;
import com.dao.orderDao;
import com.dao.userDao;

public class mainFrm extends JFrame
{



    //region 单个菜的信息框架设置
    public static class Course extends JPanel implements ActionListener
    {
        JLabel  image=new JLabel(),
                dishName=new JLabel("名称:"),
                price=new JLabel("价格（¥）:"),
                number=new JLabel("赞和踩:"),
                dishLabel=new JLabel("菜名"),
                priceLabel=new JLabel("价格");

        RoundButton minus=new RoundButton("不满意"),
                and=new RoundButton("满意"),
                minusx,
                andx;

        JLabel zan,//赞
                cai,
                numberx;//踩

        Box     north1Box,
                north2Box,
                north3Box,
                northBox,
                north4Box,
                northBox1,
                northBox2;


        JPanel buttonPanel,
                buttonPanelx,
                Course0Panel;

        JTextField numText;

        public Course(){
            minusx=new RoundButton("-");
            andx=new RoundButton("+");
            numText=new JTextField("0",2);
            buttonPanelx=new JPanel();
            buttonPanelx.add(minusx);
            buttonPanelx.add(numText);
            buttonPanelx.add(andx);
            buttonPanelx.setLayout(new FlowLayout());
            numberx=new JLabel("数量:");
            minus.setBackground(Color.YELLOW);
            minus.setSize(5,5);
            and.setBackground(Color.YELLOW);

            buttonPanel=new JPanel();
            buttonPanel.setLayout(new FlowLayout());
            buttonPanel.add(and);
            zan=new JLabel("0",10);
            buttonPanel.add(zan);
            buttonPanel.add(minus);
            cai=new JLabel("0",10);
            buttonPanel.add(cai);


            north4Box=Box.createVerticalBox();
            north4Box.add(dishName);
            north4Box.add(Box.createVerticalStrut(10));
            north4Box.add(price);


            north3Box=Box.createVerticalBox();
            north3Box.add(dishLabel);
            north3Box.add(Box.createVerticalStrut(8));
            north3Box.add(priceLabel);


            north2Box=Box.createVerticalBox();
            north2Box.add(Box.createVerticalStrut(8));
            north2Box.add(buttonPanel);
            north2Box.add(buttonPanelx);


            north1Box=Box.createVerticalBox();
            north1Box.add(number);
            north1Box.add(Box.createVerticalStrut(10));
            north1Box.add(numberx);

            northBox1=Box.createHorizontalBox();
            northBox1.add(north4Box);
            northBox1.add(Box.createHorizontalStrut(5));
            northBox1.add(north3Box);

            northBox2=Box.createHorizontalBox();
            northBox2.add(north1Box);
            northBox2.add(Box.createHorizontalStrut(5));
            northBox2.add(north2Box);

            northBox=Box.createVerticalBox();
            northBox.add(northBox1);
            northBox.add(Box.createVerticalStrut(8));
            northBox.add(northBox2);


            Course0Panel=new JPanel();
            Course0Panel.setLayout(new FlowLayout());
            Course0Panel.add(image);
            Course0Panel.add(northBox);

            minus.addActionListener(this);
            and.addActionListener(this);
            minusx.addActionListener(this);
            andx.addActionListener(this);

            add(Course0Panel);

            this.setBorder(new EtchedBorder(EtchedBorder.RAISED));
            this.setLayout(new FlowLayout());

            this.setVisible(true);
            this.validate();
        }

        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource()==minus)
            {
                int num=Integer.parseInt(cai.getText());
                num++;
                cai.setText(String.valueOf(num));

            }
            if(e.getSource()==and)
            {
                int num=Integer.parseInt(zan.getText());
                num++;
                zan.setText(String.valueOf(num));
            }
            if(e.getSource()==minusx)
            {
                int num=Integer.parseInt(numText.getText());
                num--;
                numText.setText(String.valueOf(num));

            }
            if(e.getSource()==andx)
            {
                int num=Integer.parseInt(numText.getText());
                num++;
                numText.setText(String.valueOf(num));
            }
        }
    }
    //endregion

    //region 所有的菜名与价格
    Info InfoPanel;
    Table TablePanel;

    Box winBox;

    mainFrm()

    {
        setTitle("主页面");
        InfoPanel=new Info();
        TablePanel=new Table();
        connectMySQL connectMySQL = new connectMySQL();


        Container con=getContentPane();
        winBox=Box.createVerticalBox();
        TablePanel.setSize(900,500);

        InfoPanel.setSize(900,200);
        winBox.add(InfoPanel);
        winBox.add(Box.createVerticalStrut(8));
        winBox.add(TablePanel);
        con.add(winBox);

        Connection co=null;
        co = connectMySQL.getCon();
            try {
                Statement sql=co.createStatement();


                //第一种菜
                    ResultSet res=sql.executeQuery("select *from goods where id=0");
                    while(res.next()) {
                        TablePanel.cp[0].c[0].dishLabel.setText(res.getString("goodsName"));
                        TablePanel.cp[0].c[0].priceLabel.setText(res.getString("price"));
                        TablePanel.cp[0].c[0].image.setIcon(new ImageIcon(res.getString("image")));
                    }


                ResultSet res1=sql.executeQuery("select *from goods where id=1");
                while(res1.next()) {
                    TablePanel.cp[0].c[1].dishLabel.setText(res1.getString("goodsName"));
                    TablePanel.cp[0].c[1].priceLabel.setText(res1.getString("price"));
                    TablePanel.cp[0].c[1].image.setIcon(new ImageIcon(res1.getString("image")));
                }

                ResultSet res2=sql.executeQuery("select *from goods where id=2");
                while(res2.next()) {
                    TablePanel.cp[0].c[2].dishLabel.setText(res2.getString("goodsName"));
                    TablePanel.cp[0].c[2].priceLabel.setText(res2.getString("price"));
                    TablePanel.cp[0].c[2].image.setIcon(new ImageIcon(res2.getString("image")));
                }

                ResultSet res3=sql.executeQuery("select *from goods where id=3");
                while(res3.next()) {
                    TablePanel.cp[0].c[3].dishLabel.setText(res3.getString("goodsName"));
                    TablePanel.cp[0].c[3].priceLabel.setText(res3.getString("price"));
                    TablePanel.cp[0].c[3].image.setIcon(new ImageIcon(res3.getString("image")));
                }

                ResultSet res4=sql.executeQuery("select *from goods where id=4");
                while(res4.next()) {
                    TablePanel.cp[0].c[4].dishLabel.setText(res4.getString("goodsName"));
                    TablePanel.cp[0].c[4].priceLabel.setText(res4.getString("price"));
                    TablePanel.cp[0].c[4].image.setIcon(new ImageIcon(res4.getString("image")));
                }

                ResultSet res5=sql.executeQuery("select *from goods where id=5");
                while(res5.next()) {
                    TablePanel.cp[0].c[5].dishLabel.setText(res5.getString("goodsName"));
                    TablePanel.cp[0].c[5].priceLabel.setText(res5.getString("price"));
                    TablePanel.cp[0].c[5].image.setIcon(new ImageIcon(res5.getString("image")));
                }

                ResultSet res6=sql.executeQuery("select *from goods where id=6");
                while(res6.next()) {
                    TablePanel.cp[0].c[6].dishLabel.setText(res6.getString("goodsName"));
                    TablePanel.cp[0].c[6].priceLabel.setText(res6.getString("price"));
                    TablePanel.cp[0].c[6].image.setIcon(new ImageIcon(res6.getString("image")));
                }

                ResultSet res7=sql.executeQuery("select *from goods where id=7");
                while(res7.next()) {
                    TablePanel.cp[0].c[7].dishLabel.setText(res7.getString("goodsName"));
                    TablePanel.cp[0].c[7].priceLabel.setText(res7.getString("price"));
                    TablePanel.cp[0].c[7].image.setIcon(new ImageIcon(res7.getString("image")));
                }

                ResultSet res8=sql.executeQuery("select *from goods where id=8");
                while(res8.next()) {
                    TablePanel.cp[0].c[8].dishLabel.setText(res8.getString("goodsName"));
                    TablePanel.cp[0].c[8].priceLabel.setText(res8.getString("price"));
                    TablePanel.cp[0].c[8].image.setIcon(new ImageIcon(res8.getString("image")));
                }


                //第二种菜
                ResultSet re=sql.executeQuery("select *from goods where id=9");
                while(re.next()) {
                    TablePanel.cp[1].c[0].dishLabel.setText(res.getString("goodsName"));
                    TablePanel.cp[1].c[0].priceLabel.setText(res.getString("price"));
                    TablePanel.cp[1].c[0].image.setIcon(new ImageIcon(re.getString("image")));
                }


                ResultSet re1=sql.executeQuery("select *from goods where id=10");
                while(re1.next()) {
                    TablePanel.cp[1].c[1].dishLabel.setText(res1.getString("goodsName"));
                    TablePanel.cp[1].c[1].priceLabel.setText(res1.getString("price"));
                    TablePanel.cp[1].c[1].image.setIcon(new ImageIcon(re1.getString("image")));
                }

                ResultSet re2=sql.executeQuery("select *from goods where id=11");
                while(re2.next()) {
                    TablePanel.cp[1].c[2].dishLabel.setText(res2.getString("goodsName"));
                    TablePanel.cp[1].c[2].priceLabel.setText(res2.getString("price"));
                    TablePanel.cp[1].c[2].image.setIcon(new ImageIcon(re2.getString("image")));
                }

                ResultSet re3=sql.executeQuery("select *from goods where id=12");
                while(res3.next()) {
                    TablePanel.cp[1].c[3].dishLabel.setText(res3.getString("goodsName"));
                    TablePanel.cp[1].c[3].priceLabel.setText(res3.getString("price"));
                    TablePanel.cp[1].c[3].image.setIcon(new ImageIcon(re3.getString("image")));
                }

                ResultSet re4=sql.executeQuery("select *from goods where id=13");
                while(re4.next()) {
                    TablePanel.cp[1].c[4].dishLabel.setText(res4.getString("goodsName"));
                    TablePanel.cp[1].c[4].priceLabel.setText(res4.getString("price"));
                    TablePanel.cp[1].c[4].image.setIcon(new ImageIcon(re4.getString("image")));
                }

                ResultSet re5=sql.executeQuery("select *from goods where id=14");
                while(re5.next()) {
                    TablePanel.cp[1].c[5].dishLabel.setText(res5.getString("goodsName"));
                    TablePanel.cp[1].c[5].priceLabel.setText(res5.getString("price"));
                    TablePanel.cp[1].c[5].image.setIcon(new ImageIcon(re5.getString("image")));
                }

                ResultSet re6=sql.executeQuery("select *from goods where id=15");
                while(re6.next()) {
                    TablePanel.cp[1].c[6].dishLabel.setText(res6.getString("goodsName"));
                    TablePanel.cp[1].c[6].priceLabel.setText(res6.getString("price"));
                    TablePanel.cp[1].c[6].image.setIcon(new ImageIcon(re6.getString("image")));
                }

                ResultSet re7=sql.executeQuery("select *from goods where id=16");
                while(re7.next()) {
                    TablePanel.cp[1].c[7].dishLabel.setText(res7.getString("goodsName"));
                    TablePanel.cp[1].c[7].priceLabel.setText(res7.getString("price"));
                    TablePanel.cp[1].c[7].image.setIcon(new ImageIcon(re7.getString("image")));
                }

                ResultSet re8=sql.executeQuery("select *from goods where id=17");
                while(re8.next()) {
                    TablePanel.cp[1].c[8].dishLabel.setText(res8.getString("goodsName"));
                    TablePanel.cp[1].c[8].priceLabel.setText(res8.getString("price"));
                    TablePanel.cp[1].c[8].image.setIcon(new ImageIcon(re8.getString("image")));
                }

                ResultSet es=sql.executeQuery("select *from goods where id=18");
                while(es.next()) {
                    TablePanel.cp[2].c[0].dishLabel.setText(res.getString("goodsName"));
                    TablePanel.cp[2].c[0].priceLabel.setText(res.getString("price"));
                    TablePanel.cp[2].c[0].image.setIcon(new ImageIcon(es.getString("image")));
                }


                ResultSet es1=sql.executeQuery("select *from goods where id=19");
                while(es1.next()) {
                    TablePanel.cp[2].c[1].dishLabel.setText(res1.getString("goodsName"));
                    TablePanel.cp[2].c[1].priceLabel.setText(res1.getString("price"));
                    TablePanel.cp[2].c[1].image.setIcon(new ImageIcon(es1.getString("image")));
                }

                ResultSet es2=sql.executeQuery("select *from goods where id=20");
                while(es2.next()) {
                    TablePanel.cp[2].c[2].dishLabel.setText(res2.getString("goodsName"));
                    TablePanel.cp[2].c[2].priceLabel.setText(res2.getString("price"));
                    TablePanel.cp[2].c[2].image.setIcon(new ImageIcon(es2.getString("image")));
                }

                ResultSet es3=sql.executeQuery("select *from goods where id=21");
                while(es3.next()) {
                    TablePanel.cp[2].c[3].dishLabel.setText(res3.getString("goodsName"));
                    TablePanel.cp[2].c[3].priceLabel.setText(res3.getString("price"));
                    TablePanel.cp[2].c[3].image.setIcon(new ImageIcon(es3.getString("image")));
                }

                ResultSet es4=sql.executeQuery("select *from goods where id=22");
                while(es4.next()) {
                    TablePanel.cp[2].c[4].dishLabel.setText(res4.getString("goodsName"));
                    TablePanel.cp[2].c[4].priceLabel.setText(res4.getString("price"));
                    TablePanel.cp[2].c[4].image.setIcon(new ImageIcon(es4.getString("image")));
                }

                ResultSet es5=sql.executeQuery("select *from goods where id=23");
                while(es5.next()) {
                    TablePanel.cp[2].c[5].dishLabel.setText(res5.getString("goodsName"));
                    TablePanel.cp[2].c[5].priceLabel.setText(res5.getString("price"));
                    TablePanel.cp[2].c[5].image.setIcon(new ImageIcon(es5.getString("image")));
                }

                ResultSet es6=sql.executeQuery("select *from goods where id=24");
                while(es6.next()) {
                    TablePanel.cp[2].c[6].dishLabel.setText(res6.getString("goodsName"));
                    TablePanel.cp[2].c[6].priceLabel.setText(res6.getString("price"));
                    TablePanel.cp[2].c[6].image.setIcon(new ImageIcon(es6.getString("image")));
                }

                ResultSet es7=sql.executeQuery("select *from goods where id=25");
                while(es7.next()) {
                    TablePanel.cp[2].c[7].dishLabel.setText(res7.getString("goodsName"));
                    TablePanel.cp[2].c[7].priceLabel.setText(res7.getString("price"));
                    TablePanel.cp[2].c[7].image.setIcon(new ImageIcon(es7.getString("image")));
                }

                ResultSet es8=sql.executeQuery("select *from goods where id=26");
                while(es8.next()) {
                    TablePanel.cp[2].c[8].dishLabel.setText(res8.getString("goodsName"));
                    TablePanel.cp[2].c[8].priceLabel.setText(res8.getString("price"));
                    TablePanel.cp[2].c[8].image.setIcon(new ImageIcon(es8.getString("image")));
                }


            } catch (SQLException e) {
                e.printStackTrace();
            }


        this.setBounds(100,100,1000,500);
        this.setTitle("网上订餐系统");
        this.setVisible(true);
        this.validate();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    //endregion

    //region 菜单九宫格布局
    public static class Course9Panel extends JPanel
    {
        Box n1boxa,n1boxb,n1boxc,//菜
                n9box,//菜*1
                scrollbox;//菜盒子

        Course c[]=new Course[9]; //菜*9

        JPanel n1a,n1b,n1c,//川菜*3
                s1;//菜界面

        JScrollPane scroll;//菜列表

        public Course9Panel()
        {
            s1=new JPanel();
            //菜*9
            for(int i=0;i<9;i++) {
                c[i]=new Course();
            }
            n1boxa=Box.createHorizontalBox();
            n1boxa.add(c[0]);
            n1boxa.add(Box.createHorizontalStrut(8));
            n1boxa.add(c[1]);
            n1boxa.add(Box.createHorizontalStrut(8));
            n1boxa.add(c[2]);
            n1boxb=Box.createHorizontalBox();
            n1boxb.add(c[3]);
            n1boxb.add(Box.createHorizontalStrut(8));
            n1boxb.add(c[4]);
            n1boxb.add(Box.createHorizontalStrut(8));
            n1boxb.add(c[5]);
            n1boxc=Box.createHorizontalBox();
            n1boxc.add(c[6]);
            n1boxc.add(Box.createHorizontalStrut(8));
            n1boxc.add(c[7]);
            n1boxc.add(Box.createHorizontalStrut(8));
            n1boxc.add(c[8]);
            //川菜*3
            n1a=new JPanel();
            n1a.setLayout(new FlowLayout());
            n1a.add(n1boxa);
            add(n1a);

            n1b=new JPanel();
            n1b.setLayout(new FlowLayout());
            n1b.add(n1boxb);
            add(n1b);

            n1c=new JPanel();
            n1c.setLayout(new FlowLayout());
            n1c.add(n1boxc);
            add(n1c);

            //川菜*1
            n9box=Box.createVerticalBox();
            n9box.add(n1a);
            n9box.add(Box.createVerticalStrut(5));
            n9box.add(n1b);
            n9box.add(Box.createVerticalStrut(5));
            n9box.add(n1c);

            //川菜列表
            scroll=new JScrollPane(n9box)
            {
                public Dimension getPreferredSize()
                {
                    return new Dimension(800,350);
                }
            };
            scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            s1.add(scroll);
            this.add(s1);
            this.setBorder(new EtchedBorder(EtchedBorder.RAISED));
            this.setLayout(new FlowLayout());
            this.setSize(850,450);
            this.setVisible(true);
            this.validate();
        }
    }
            //endregion

    //region 用户，优惠，订单
    public class Info extends JPanel{

        JPanel northPanel;


        JButton userButton=new JButton("用户"),
                discountButton=new JButton("优惠"),
                shopButton=new JButton("确认");

        JLabel userLabel,
                discountLabel,
                shopLabel;

        public Info()
        {
            northPanel=new JPanel();


            northPanel.add(userButton);
            userLabel=new JLabel(loginFrm.currentUser.getUserName());
            northPanel.add(userLabel);

            northPanel.add(discountButton);
            discountLabel=new JLabel("全场八折优惠");
            northPanel.add(discountLabel);

            northPanel.add(shopButton);
            shopLabel=new JLabel();
            northPanel.add(shopLabel);

            userButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    userButtonActionPerformed(evt);
                }
            });

            discountButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                  discountButtonActionPerFormed(evt);
                }
            });

            shopButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    shopButtonActionPerformed(evt);
                }
            });



            this.setBounds(100,100,455,200);
            this.setLayout(new FlowLayout());
            this.add(northPanel);
            this.setVisible(true);
            this.validate();
        }
    }
    //endregion

    //region菜系选择
    public static class Table extends JPanel
    {
        Course9Panel cp[]=new Course9Panel[9];

        JTabbedPane jtp;// 选项卡窗格

        public Table()
        {
            jtp = new JTabbedPane();
            for(int i=0;i<3;i++) {
                cp[i]=new Course9Panel();
            }

            jtp.addTab("川菜", null,cp[0],"First panel");// 参数：选项卡名称，面板
            jtp.addTab("湘菜", null,cp[1],"Second panel");
            jtp.addTab("鲁菜", null,cp[2],"Third panel");

            this.add(jtp, BorderLayout.CENTER);
            this.setSize(1000, 500);
            this.setVisible(true);
        }
    }
    //endregion

    //region 赞和踩的按钮
    public static class RoundButton extends JButton{
        public RoundButton(String label) {
            super(label);
            Dimension size=new Dimension();
            size.width=size.height=12;
            setPreferredSize(size);
            setContentAreaFilled(false);
        }
        protected void paintComponent(Graphics g) {
            if(getModel().isArmed()) {
                g.setColor(Color.blue);
            }
            else {
                g.setColor(getBackground());
            }
            g.fillOval(0, 0, getSize().width-1,getSize().height-1);
            super.paintComponent(g);
        }
        protected void paintBorder(Graphics g) {
            g.setColor(getForeground());
            g.drawOval(0,0,getSize().width-1,getSize().height-1);
        }
        Shape shape;
        public boolean contains(int x,int y) {
            if(shape==null||!shape.getBounds().equals(getBounds())) {
                shape=new Ellipse2D.Float(0,0,getWidth(),getHeight());
            }
            return shape.contains(x,y);
        }
    }
    //endregion

    //region 响应函数

    private void userButtonActionPerformed(ActionEvent evt) {
        new accountModifyInterFrm().setVisible(true);

    }

    private void discountButtonActionPerFormed(ActionEvent evt){
    JOptionPane.showMessageDialog(null, "总消费额达500成为vip，可享优惠哦！","提示",1);
}

    public void shopButtonActionPerformed(ActionEvent e) {
            orderFrm w=new orderFrm("订单界面");
            for(int i=0;i<3;i++) {
                for(int j=0;j<9;j++) {
                    int num=Integer.parseInt(TablePanel.cp[i].c[j].numText.getText());
                    if(num>0) {
                        for(int m=0;m<6;m++) {
                            int numx=Integer.parseInt(w.n[m].numberText.getText());
                            if(numx==0) {
                                w.n[m].dishLabel.setText(TablePanel.cp[i].c[j].dishLabel.getText());
                                w.n[m].priceLabel.setText(TablePanel.cp[i].c[j].priceLabel.getText());
                                w.n[m].numberText.setText(TablePanel.cp[i].c[j].numText.getText());
                                break;
                            }
                        }
                    }
                }
            }
            double sum=0;
            for(int i=0;i<6;i++) {
                if(Integer.parseInt(w.n[i].numberText.getText())>0) {
                    double numx=Double.parseDouble(w.n[i].numberText.getText());
                    double pricex=Double.parseDouble(w.n[i].priceLabel.getText());
                    sum=sum+numx*pricex;
                    System.out.println(sum);
                }
            }

            if(loginFrm.currentUser.getVip().equals("是")) {
                sum = sum * 0.8;
                w.totalLabel.setText(String.valueOf(sum));
            }

            if(loginFrm.currentUser.getVip().equals("否")){

                w.totalLabel.setText(String.valueOf(sum));
                Connection con=null;

                try {
                    con=connectMySQL.getCon();
                    userDao.vipJudge(con,sum);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }


            }

            //判断是否为vip进行进一步优惠

            //将优惠信息写入订单界面的discountLabel

            //将总价写入订单界面的totalLabel中
    }

    //endregion

    //region 主函数
    public static void main(String args[])
    {	mainFrm mainFrm =new mainFrm();}
    //endregion

}
