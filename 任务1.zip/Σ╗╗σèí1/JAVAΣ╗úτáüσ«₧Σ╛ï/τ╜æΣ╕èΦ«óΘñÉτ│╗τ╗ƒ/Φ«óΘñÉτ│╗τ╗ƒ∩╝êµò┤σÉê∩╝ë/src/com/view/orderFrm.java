//author:赵季程

package com.view;

import com.auxiliary.connectMySQL;
import com.dao.orderDao;
import com.dao.userDao;
import com.model.Order;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.sql.Connection;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;


public class orderFrm extends JFrame implements ActionListener {

    com.auxiliary.connectMySQL connectMySQL = new connectMySQL();
    com.dao.userDao userDao = new userDao();
    com.dao.orderDao orderDao = new orderDao();

    //region 订单中的菜的信息
    public static class north extends JPanel {
        JLabel image = new JLabel("图片"),
                dishName = new JLabel("名称:"),
                price = new JLabel("价格:"),
                number = new JLabel("数量:"),
                dishLabel = new JLabel(""),
                priceLabel = new JLabel("");


        orderRoundButton minus = new orderRoundButton("-"),
                and = new orderRoundButton("+");

        JTextField numberText;

        Box north1Box,
                north2Box,
                northBox;

        JPanel buttonPanel,
                northxPanel;

        public north() {
            minus.setBackground(Color.YELLOW);
            and.setBackground(Color.YELLOW);
            numberText = new JTextField("0", 2);
            buttonPanel = new JPanel();
            buttonPanel.setLayout(new FlowLayout());
            buttonPanel.add(minus);
            buttonPanel.add(numberText);
            buttonPanel.add(and);
            north2Box = Box.createVerticalBox();
            north2Box.add(dishLabel);
            north2Box.add(Box.createVerticalStrut(8));
            north2Box.add(priceLabel);
            north2Box.add(Box.createVerticalStrut(8));
            north2Box.add(buttonPanel);
            north1Box = Box.createVerticalBox();
            north1Box.add(dishName);
            north1Box.add(Box.createVerticalStrut(8));
            north1Box.add(price);
            north1Box.add(Box.createVerticalStrut(8));
            north1Box.add(number);
            northBox = Box.createHorizontalBox();
            northBox.add(north1Box);
            northBox.add(Box.createHorizontalStrut(20));
            northBox.add(north2Box);
            northxPanel = new JPanel();
            northxPanel.setLayout(new FlowLayout());
            northxPanel.add(image);
            northxPanel.add(northBox);

            add(northxPanel);
            this.setBorder(new EtchedBorder(EtchedBorder.RAISED));
            this.setLayout(new FlowLayout());
            this.setVisible(true);
            this.validate();
        }
    }
    //endregion

    //region 订单
    JLabel consignee,//收货人标签
            shippingAddress,//收货地址标签
            discount,//折扣信息标签
            total,//总价标签
            discountLabel,//具体折扣信息
            totalLabel;//具体总价

    JPanel centerPanel,//中间面板
            southPanel;//下端面板
    //菜品栏面板
    north n[] = new north[6];

    Box baseBox,
            northxBox,
            center1Box,
            center2Box;

    JScrollPane pane;//滚动列表

    JTextField textName,//收货人文本框
            textAddress;//收货地址文本框
    JButton button;//确认按钮

    orderFrm(String s) {
        setTitle(s);
        //各个标签附初值
        consignee = new JLabel("收货人：");
        shippingAddress = new JLabel("收货地址:");
        discount = new JLabel("折扣：");
        total = new JLabel("总价：");
        discountLabel = new JLabel("无优惠");
        totalLabel = new JLabel("0");
        //设置图片


        //*****
        textName = new JTextField(12);
        textAddress = new JTextField(12);

        textName.setText(loginFrm.currentUser.getUserName());
        textAddress.setText(loginFrm.currentUser.getAddress());

        button = new JButton("确认");
        Container con = getContentPane();//提取面板容器
        //优惠取值

        if (loginFrm.currentUser.getVip().equals("是"))
            discountLabel.setText("八折优惠");


        //
        //最底端面板south绘制
        southPanel = new JPanel();
        southPanel.setSize(445, 59);
        southPanel.setLayout(new FlowLayout());
        southPanel.add(discount);
        southPanel.add(discountLabel);
        southPanel.add(button);
        southPanel.add(total);
        southPanel.add(totalLabel);
        //中部面板center绘制
        centerPanel = new JPanel();
        center1Box = Box.createVerticalBox();
        center1Box.add(consignee);
        center1Box.add(Box.createVerticalStrut(8));
        center1Box.add(shippingAddress);
        center2Box = Box.createVerticalBox();
        center2Box.add(textName);
        center2Box.add(Box.createVerticalStrut(8));
        center2Box.add(textAddress);
        centerPanel.setLayout(new FlowLayout());
        centerPanel.add(center1Box);
        centerPanel.add(center2Box);
        centerPanel.setBorder(new EtchedBorder(EtchedBorder.RAISED));
        //上部板的绘制

        for (int i = 0; i < 6; i++) {
            n[i] = new north();
        }

        northxBox = Box.createVerticalBox();
        northxBox.add(n[0]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[1]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[2]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[3]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[4]);
        northxBox.add(Box.createVerticalStrut(2));
        northxBox.add(n[5]);

        pane = new JScrollPane(northxBox) {
            public Dimension getPreferredSize() {
                return new Dimension(445, 100);
            }
        };
        pane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        baseBox = Box.createVerticalBox();
        baseBox.add(pane);
        baseBox.add(Box.createVerticalStrut(10));
        baseBox.add(centerPanel);
        baseBox.add(Box.createVerticalStrut(10));
        baseBox.add(southPanel);
        con.add(baseBox);
        con.setLayout(new FlowLayout());
        setSize(455, 300);
        button.addActionListener(this);
        for (int i = 0; i < 6; i++) {
            n[i].minus.addActionListener(this);
            n[i].and.addActionListener(this);
        }


        setVisible(true);
        validate();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    //endregion

    //region 按钮设置
    public static class orderRoundButton extends JButton {
        public orderRoundButton(String label) {
            super(label);
            Dimension size = new Dimension();
            size.width = size.height = 12;
            setPreferredSize(size);
            setContentAreaFilled(false);
        }

        protected void paintComponent(Graphics g) {
            if (getModel().isArmed()) {
                g.setColor(Color.blue);
            } else {
                g.setColor(getBackground());
            }
            g.fillOval(0, 0, getSize().width - 1, getSize().height - 1);
            super.paintComponent(g);
        }

        protected void paintBorder(Graphics g) {
            g.setColor(getForeground());
            g.drawOval(0, 0, getSize().width - 1, getSize().height - 1);
        }

        Shape shape;

        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new Ellipse2D.Float(0, 0, getWidth(), getHeight());
            }
            return shape.contains(x, y);
        }
    }
    //endregion

    //minus，and，确认,事件
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == n[0].minus) {
            int num = Integer.parseInt(n[0].numberText.getText());
            num--;
            n[0].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[0].and) {
            int num = Integer.parseInt(n[0].numberText.getText());
            num++;
            n[0].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[1].minus) {
            int num = Integer.parseInt(n[1].numberText.getText());
            num--;
            n[1].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[1].and) {
            int num = Integer.parseInt(n[1].numberText.getText());
            num++;
            n[1].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[2].minus) {
            int num = Integer.parseInt(n[2].numberText.getText());
            num--;
            n[2].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[2].and) {
            int num = Integer.parseInt(n[2].numberText.getText());
            num++;
            n[2].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[3].minus) {
            int num = Integer.parseInt(n[3].numberText.getText());
            num--;
            n[3].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[3].and) {
            int num = Integer.parseInt(n[3].numberText.getText());
            num++;
            n[3].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[4].minus) {
            int num = Integer.parseInt(n[4].numberText.getText());
            num--;
            n[4].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[4].and) {
            int num = Integer.parseInt(n[4].numberText.getText());
            num++;
            n[4].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[5].minus) {
            int num = Integer.parseInt(n[5].numberText.getText());
            num--;
            n[5].numberText.setText(String.valueOf(num));
        }
        if (e.getSource() == n[5].and) {
            int num = Integer.parseInt(n[5].numberText.getText());
            num++;
            n[5].numberText.setText(String.valueOf(num));
        }


        if (e.getSource() == button) {

            String userName = loginFrm.currentUser.getUserName();
            String userAddress = loginFrm.currentUser.getAddress();
            String discount = this.discountLabel.getText();
            String totalCost = this.totalLabel.getText();
            String gNa0 = this.n[0].dishLabel.getText();
            String gNu0 = this.n[0].numberText.getText();
            String gPr0 = this.n[0].priceLabel.getText();


            String gNa1 = this.n[1].dishLabel.getText();
            String gNu1 = this.n[1].numberText.getText();
            String gPr1 = this.n[1].priceLabel.getText();

            String gNa2 = this.n[2].dishLabel.getText();
            String gNu2 = this.n[2].numberText.getText();
            String gPr2 = this.n[2].priceLabel.getText();

            String gNa3 = this.n[3].dishLabel.getText();
            String gNu3 = this.n[3].numberText.getText();
            String gPr3 = this.n[3].priceLabel.getText();

            String gNa4 = this.n[4].dishLabel.getText();
            String gNu4 = this.n[4].numberText.getText();
            String gPr4 = this.n[4].priceLabel.getText();

            String gNa5 = this.n[5].dishLabel.getText();
            String gNu5 = this.n[5].numberText.getText();
            String gPr5 = this.n[5].priceLabel.getText();


            Connection con = null;
            try {
                con = connectMySQL.getCon();
                Order orde = new Order(userName, userAddress, discount, totalCost, gNa0, gNu0, gPr0, gNa1, gNu1, gPr1, gNa2, gNu2, gPr2, gNa3, gNu3, gPr3, gNa4, gNu4, gPr4, gNa5, gNu5, gPr5);
                int addNum = orderDao.orderAdd(con, orde);//插入数据到order表
                if (addNum == 1) {
                    JOptionPane.showMessageDialog(null, "订单提交成功");
                } else {
                    JOptionPane.showMessageDialog(null, "订单提交失败");
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            } finally {
                try {
                    connectMySQL.closeCon(con);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                this.setVisible(false);
            }

        }
    }

    public static void main (String args[]){
            orderFrm win = new orderFrm("订单");
        }
}
