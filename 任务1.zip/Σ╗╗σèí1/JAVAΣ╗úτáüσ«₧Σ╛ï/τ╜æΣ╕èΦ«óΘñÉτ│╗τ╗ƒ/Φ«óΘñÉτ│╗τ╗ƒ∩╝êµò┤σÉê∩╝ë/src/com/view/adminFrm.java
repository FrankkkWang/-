/*
 * AdminFrm.java
 *
 * Created on __DATE__, __TIME__
 */

package com.view;

import com.auxiliary.connectMySQL;
import com.dao.userDao;
import com.dao.orderDao;
import com.model.Order;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class adminFrm extends JFrame {

    //region 变量声明
    com.auxiliary.connectMySQL connectMySQL = new connectMySQL();
    userDao userDao = new userDao();
    orderDao orderDao = new orderDao();

    private JButton jLabel1;
    private JButton jLabel2;
    private JButton jLabel3;
    //endregion

    //region 窗体位置
    public  adminFrm() {
        initComponents();
        this.setLocation(600, 150);
    }
    //endregion

    //region 组件布局
    private void initComponents() {

        //region 定义变量
        jLabel1 = new JButton();
        jLabel2 = new JButton();
        jLabel3 = new JButton();
        //endregion

        //region 窗体设置
        this.setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("管理");
        //endregion

        //region文本输出设置及注册侦听函数
        jLabel1.setText("添加新菜");

        jLabel2.setText("删除菜肴");

        jLabel3.setText("查看订单");


        jLabel1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jb1ActionPerformed(evt);
            }
        });

        jLabel2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jb2ActionPerformed(evt);
            }
        });

        jLabel3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                try {
                    jb3ActionPerformed(evt);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);

        //region 水平布局

        //确认键与取消键水平串行
        //region 信息文本水平并行
        GroupLayout.ParallelGroup PG2=layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                .addComponent(jLabel1)
                .addComponent(jLabel2)
                .addComponent(jLabel3);
        //endregion


        //endregion

        //region 整体水平调整
        GroupLayout.ParallelGroup PG4=layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(PG2)
                        .addGap(60, 60, 60));
        //endregion

        //水平设置
        layout.setHorizontalGroup(PG4);
        //endregion

        //region 竖直布局

        //按键竖直并行

        GroupLayout.ParallelGroup PG_6=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel3);
        GroupLayout.ParallelGroup PG_7=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel2);
        GroupLayout.ParallelGroup PG_8=layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel1);

        GroupLayout.SequentialGroup SG_1=layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(PG_8)
                .addGap(18, 18, 18)
                .addGroup(PG_7)
                .addGap(18, 18, 18)
                .addGroup(PG_6)
                .addGap(18, 18, 18);

        GroupLayout.ParallelGroup PG_9=layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(GroupLayout.Alignment.TRAILING, SG_1);

        layout.setVerticalGroup(PG_9);

        pack();
        //endregion
    }

    //endregion


    //订单处理操作
    private void jb3ActionPerformed(ActionEvent evt) throws Exception {

        Connection con = null;
        con = connectMySQL.getCon();

        orderDao.orderDisplay(con);
    }

    //删除菜
    private void jb2ActionPerformed(ActionEvent evt) {
        goodsDelFrm goodsManageInterFrm = new goodsDelFrm();
        goodsManageInterFrm.setVisible(true);

    }
    //添加菜
    private void jb1ActionPerformed(ActionEvent evt) {
        goodsAddFrm goodsAddInterFrm = new goodsAddFrm();
        goodsAddInterFrm.setVisible(true);
    }



    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new adminFrm().setVisible(true);
            }
        });
    }

}
