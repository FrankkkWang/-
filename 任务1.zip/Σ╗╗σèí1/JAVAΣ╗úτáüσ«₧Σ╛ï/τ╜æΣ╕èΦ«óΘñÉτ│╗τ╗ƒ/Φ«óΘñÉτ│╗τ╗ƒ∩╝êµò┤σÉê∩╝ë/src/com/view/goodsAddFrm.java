package com.view;

import java.io.File;
import java.sql.Connection;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.dao.goodsDao;
import com.model.Goods;
import com.auxiliary.connectMySQL;

public class goodsAddFrm extends JFrame {

    //region 声明变量
    connectMySQL connectMySQL = new connectMySQL();
    goodsDao goodsDao = new goodsDao();

    private JTextArea goodsDescTxt;
    private JTextField goodsNameTxt;
    private JTextField imageLinkTxt;
    private JTextField ID;
    private JLabel jLabel1;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JScrollPane jScrollPane1;
    private JButton jb_add;
    private JButton jb_chooser;
    private JButton jb_reset;
    private JTextField priceTxt;
    //endregion

    public goodsAddFrm() {
        initComponents();
        this.setLocation(200, 80);
    }

    private void initComponents() {

        //region 定义变量
        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jb_chooser = new JButton();
        ID = new JTextField();
        imageLinkTxt = new JTextField();
        goodsNameTxt = new JTextField();
        priceTxt = new JTextField();
        jLabel5 = new JLabel();
        jScrollPane1 = new JScrollPane();
        goodsDescTxt = new JTextArea();
        jb_add = new JButton();
        jb_reset = new JButton();
        //endregion

        this.setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("添加菜品");

        jLabel1.setText("位置：");

        jLabel2.setText("菜名：");

        jLabel3.setText("价格：");

        jLabel4.setText("简介：");

        jb_chooser.setText("选择");
        jb_chooser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jb_chooserActionPerformed(evt);
            }
        });


        imageLinkTxt.setEditable(false);


        jLabel5.setText("照片：");

        goodsDescTxt.setColumns(20);
        goodsDescTxt.setRows(5);
        jScrollPane1.setViewportView(goodsDescTxt);

        jb_add.setText("添加");
        jb_add.addActionListener(new ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_addActionPerformed(evt);
            }
        });


        jb_reset.setText("取消");
        jb_reset.addActionListener(new ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_resetActionPerformed(evt);
            }
        });

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                        .addContainerGap()
                                                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                                        .addComponent(jLabel2)
                                                                                        .addGroup(layout.createSequentialGroup()
                                                                                                        .addComponent(jLabel3)
                                                                                                        .addGap(30, 30, 30)
                                                                                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                                                                        .addComponent(priceTxt, GroupLayout.PREFERRED_SIZE, 103, GroupLayout.PREFERRED_SIZE)
                                                                                                                        .addGroup(layout.createSequentialGroup()
                                                                                                                                        .addComponent(goodsNameTxt, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)
                                                                                                                                        .addGap(49, 49, 49)
                                                                                                                                        .addComponent(jLabel5)
                                                                                                                        )
                                                                                                                        .addComponent(jScrollPane1, GroupLayout.PREFERRED_SIZE, 230, GroupLayout.PREFERRED_SIZE)))
                                                                                        .addComponent(jLabel4))
                                                                        .addGap(4, 4, 4)
                                                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                                                        .addGroup(layout.createSequentialGroup()
                                                                                                        .addGap(47, 47, 47)
                                                                                                        .addComponent(jb_reset))
                                                                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                        .addComponent(jLabel1)
                                                                                                        .addComponent(ID, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE))
                                                                                                .addComponent(jb_chooser)
                                                                                                .addComponent(imageLinkTxt, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE)
                                                                                        )
                                                                        )
                                                        )
                                                        .addGroup(layout.createSequentialGroup()
                                                                        .addGap(56, 56, 56)
                                                                        .addComponent(jb_add)
                                                        )
                                        )
                                        .addContainerGap(32, Short.MAX_VALUE)
                        )
        );

        layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel2)
                                                        .addComponent(goodsNameTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jLabel5)
                                                        .addComponent(imageLinkTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jLabel3)
                                                        .addComponent(priceTxt, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(jb_chooser))
                                        .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                        .addComponent(ID, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addComponent(jLabel1)
                                                        .addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                                                        .addComponent(jLabel4))
                                        .addGap(16, 16, 16)
                                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                                        .addComponent(jb_add)
                                                        .addComponent(jb_reset))
                                        .addContainerGap()
                        )
        );

        pack();
    }


    //region 添加菜
    private void jb_addActionPerformed(ActionEvent evt) {
        String goodsName = this.goodsNameTxt.getText();
        String goodsDesc = this.goodsDescTxt.getText();
        String price = this.priceTxt.getText();
        String imageLink = this.imageLinkTxt.getText();
        String id = this.ID.getText();


        if (goodsName.equals("")) {
            JOptionPane.showMessageDialog(null, "套餐名称不能为空！");
            return;
        }
        if (price.equals("")) {
            JOptionPane.showMessageDialog(null, "套餐价格不能为空！");
            return;
        }
        if (price.equals("")) {
            JOptionPane.showMessageDialog(null, "请重新输入套餐价格！");
            return;
        }

        Goods goods = new Goods(Integer.parseInt(id),goodsName, goodsDesc, Float.parseFloat(price),
                imageLink);

        Connection con = null;
        try {
            con = connectMySQL.getCon();
            int n = goodsDao.GoodsAdd(con, goods);
            if (n == 1) {
                JOptionPane.showMessageDialog(null, "套餐添加成功");
                this.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(null, "套餐添加失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //endregion


    //region 取消操作
    private void jb_resetActionPerformed(ActionEvent evt) {
        this.setVisible(false);
    }
    //endregion

    //region 点击选择图片操作
    private void jb_chooserActionPerformed(ActionEvent evt) {
        JFileChooser chooser = new JFileChooser();//创建文件对话框
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & GIF Images", "jpg", "gif");//创建文件过滤器
        chooser.setFileFilter(filter);//为文件对话框设置文件过滤器
        int returnValue = chooser.showOpenDialog(getParent());//打开文件选择对话框
        if (returnValue == JFileChooser.APPROVE_OPTION) { // 判断是否选择了文件
            File file = chooser.getSelectedFile(); // 获得文件对象
            if (file.length() / 1024.0 > 50.0) {
                JOptionPane.showMessageDialog(null, "请选择小于等于50KB的图片文件。");
                return;
            }
            String picturePath = file.getAbsolutePath();//获取路径
            System.out.println(picturePath);
            this.imageLinkTxt.setText(picturePath);//文本框显示路径

        }
    }
    //endregion

}