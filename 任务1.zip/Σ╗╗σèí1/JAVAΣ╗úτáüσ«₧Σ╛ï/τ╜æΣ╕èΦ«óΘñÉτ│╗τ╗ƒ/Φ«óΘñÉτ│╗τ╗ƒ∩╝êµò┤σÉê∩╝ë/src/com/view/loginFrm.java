//author:
// 大多：赵季程
//登陆监听及其响应函数：王子琛

package com.view;

import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.border.MatteBorder;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import java.sql.Connection;
import java.awt.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.*;


import com.dao.*;
import com.model.User;
import com.auxiliary.connectMySQL;
import static com.view.loginFrm.loginWindow.*;

public class loginFrm extends JFrame implements ActionListener{

    //region 定义类变量
    connectMySQL connectMySQL = new connectMySQL();
    userDao userDao = new userDao();
    public static User currentUser=null;
    //endregion

    //region 窗体设置
    public static class loginWindow {
        public static void

        run(final JFrame f, final int width, final int height){
            SwingUtilities.invokeLater(new Runnable(){
                public void run(){
                    f.setTitle("登陆");
                    f.setDefaultCloseOperation(EXIT_ON_CLOSE);
                    f.setResizable(false);
                    //设置窗口打开居中
                    f.setLocationRelativeTo(null);
                    //窗口大小
                    f.setSize(width, height);
                    //展示窗口
                    f.setVisible(true);
                }
            });
        }
    }
    //endregion

    ///region 组件设置
    private static final long serialVersionUID = 1L;
    //设置一个Panel容器面板和Label标签存放背景图片
    private JPanel
            contentPanel = new JPanel();
    private JLabel
            label,
            label2,
            label3,
            label4,
            label5;

    //设置按钮组件
    private JButton
            login = new JButton("登录"),
            registered = new JButton("注册");
    //设置文本框组件
    private JTextField
            admin = new JTextField();
       private  JPasswordField password = new JPasswordField();


    public loginFrm(){
        //初始化各组件
        //实例化图片
        ImageIcon image1 = new ImageIcon("e://JavaWS/3.jpg");
        ImageIcon image2 = new ImageIcon("e://JavaWS/touming.png");
        JLabel backLabel = new JLabel();
        JLabel backLabel2 = new JLabel();
        backLabel.setIcon(image1);
        backLabel2.setIcon(image2);
        label=new JLabel(image1);
        label2 = new JLabel(image2);
        label3 = new JLabel();
        label4 = new JLabel();
        label5 = new JLabel();
        label3.setText("账号： ");
        label4.setText("密码： ");
        label5.setText("欢迎订餐");
        label5.setFont(new Font("宋体", 3, 32));
        //设置标签大小与位置
        label.setBounds(0, 0,500,350);
        label2.setBounds(0, 0, 501, 350);
        //在LayeredPane最底层上添加两个带图片的标签，并且label2在label上方
        this.getLayeredPane().add(label2,new Integer(Integer.MIN_VALUE));
        this.getLayeredPane().add(label,new Integer(Integer.MIN_VALUE));
        //将内容面板设置为透明，就能够看见添加在LayeredPane上的背景。
        ((JPanel)this.getContentPane()).setOpaque(false);
        contentPanel.setLayout(null);
        add(label3);
        add(label4);
        add(label5);
        add(admin);
        add(password);
        add(login);
        add(registered);
        label3.setBounds(95,130,50,25);
        label4.setBounds(95,154,50,25);
        admin.setBounds(150, 130, 250, 25);
        password.setBounds(150, 154, 250, 25);
        registered.setBounds(280, 225, 90, 20);
        login.setBounds(140, 225, 90, 20);
        label5.setBounds(195,30,200,70);
        label3.setOpaque(false);
        label4.setOpaque(false);
        admin.setOpaque(false);
        password.setOpaque(false);
        contentPanel.setOpaque(false);
        getContentPane().add(contentPanel);
        registered.addActionListener(this);

        admin.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                int c = e.getButton();
                if(c == MouseEvent.BUTTON1 && admin.getText().equals("账号/邮箱/手机号") &&e.getClickCount()==1) {
                    admin.setText(null);
                    password.setText("密码");
                }
            }
        });

        admin.addCaretListener(new CaretListener(){
            public void caretUpdate(CaretEvent e){
            }
        });

        password.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent e){
                int c = e.getButton();
                if(c == MouseEvent.BUTTON1 && password.getText().equals("密码") &&e.getClickCount()==1) {
                    password.setText(null);
                    admin.setText("账号/邮箱/手机号");
                }
            }
        });

        login.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                logonActionPerformed(evt);
            }
        });



                                }
    //endregion

    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==registered) {
            regisFrm regis=new regisFrm("新户注册");
        }
    }

    public void textSet(JTextField field) {
        field.setBackground(new Color(255, 255, 255));
        field.setPreferredSize(new Dimension(150, 28));
        MatteBorder border = new MatteBorder(0, 0, 2, 0, new Color(192, 192,
                192));
        field.setBorder(border);
    }

    //region 登陆响应函数，登陆验证
    private void logonActionPerformed(ActionEvent evt) {
        String userName = this.admin.getText();
        String password = new String (this.password.getPassword());

        //判断用户名和密码是否没填
        if (userName.equals("")) {
            JOptionPane.showMessageDialog(null, "抱歉，用户名不能为空","提示",1);
            return;
        }
        if (password.equals("")) {
            JOptionPane.showMessageDialog( null, "抱歉，密码不能为空","提示",1);
            return;
        }

        User user = new User(userName, password);  //保存当前登录用户信息
        Connection con=null;

        try {
            con = connectMySQL.getCon();
            currentUser = userDao.login(con, user);//对比数据库中的信息
            if (currentUser != null) {
                int identity=currentUser.getId();  //根据数据库中的主键id判断登录用户的身份
                if (identity==1) {                 //ID为1，则是admin，进入管理员页面
                    this.dispose();
                    new adminFrm().setVisible(true);
                    //new AdminFrm().setVisible(true);
                } else if (identity != 1) {        //不为1是普通用户进入用户点餐界面
                    this.dispose();
                    new mainFrm().setVisible(true);
                }
            }
            else {
                JOptionPane.showMessageDialog(null, "用户名或密码错误","提示",1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                connectMySQL.closeCon(con);      //关闭数据库
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
    //endregion


    public static void main(String[] args){
        run(new loginFrm(),500,350);
    }

}
