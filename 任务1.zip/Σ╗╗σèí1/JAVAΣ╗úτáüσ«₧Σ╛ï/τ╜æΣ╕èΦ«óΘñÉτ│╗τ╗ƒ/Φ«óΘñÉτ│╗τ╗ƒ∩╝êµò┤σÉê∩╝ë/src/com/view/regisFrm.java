//author：赵季程

package com.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.Box;
import java.sql.Connection;

import com.auxiliary.connectMySQL;
import com.model.User;
import com.dao.userDao;

public class regisFrm extends Frame{


    Label name;
    Label sex;
    Label phone;
    Label address;
    Label pass;
    TextField nameText;
    TextField sexText;
    TextField phoneText;
    TextField addressText;
    TextField passText;
    Panel panel;
    Box baseBox,box1,box2;
    Button sure;
    regisFrm(String s){
        setTitle(s);
        name=new Label("姓名：");
        sex=new Label("性别:");
        phone=new Label("手机号：");
        address=new Label("地址:");
        pass=new Label("密码:");
        nameText=new TextField(10);
        sexText=new TextField(10);
        phoneText=new TextField(10);
        addressText=new TextField(10);
        passText=new TextField(10);
        box1=Box.createVerticalBox();
        box1.add(Box.createVerticalStrut(8));
        box1.add(name);
        box1.add(Box.createVerticalStrut(8));
        box1.add(sex);
        box1.add(Box.createVerticalStrut(8));
        box1.add(phone);
        box1.add(Box.createVerticalStrut(8));
        box1.add(address);
        box1.add(Box.createVerticalStrut(8));
        box1.add(pass);
        box2=Box.createVerticalBox();
        box2.add(Box.createVerticalStrut(8));
        box2.add(nameText);
        box2.add(Box.createVerticalStrut(8));
        box2.add(sexText);
        box2.add(Box.createVerticalStrut(8));
        box2.add(phoneText);
        box2.add(Box.createVerticalStrut(8));
        box2.add(addressText);
        box2.add(Box.createVerticalStrut(8));
        box2.add(passText);
        baseBox=Box.createHorizontalBox();
        baseBox.add(Box.createHorizontalStrut(20));
        baseBox.add(box1);
        baseBox.add(box2);
        sure=new Button("确认");
        sure.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                sureActionPerformed(evt);
            }
        });
        panel=new Panel();
        panel.setLayout(new FlowLayout());
        panel.add(sure);
        add(baseBox);
        add(panel);
        add(baseBox,BorderLayout.CENTER);
        add(panel,BorderLayout.SOUTH);
        setBounds(80,125,300,250);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                dispose();
            }
        });
        setVisible(true);
    }

    private void sureActionPerformed(ActionEvent evt) {

        String userName = this.nameText.getText();
        String password = new String(this.passText.getText());
        String gender = this.sexText.getText();
        String tele = this.phoneText.getText();
        String address = this.addressText.getText();


        //判断填写是否为空
        if (userName.equals("")) {
            JOptionPane.showMessageDialog(null, "用户名不能为空");
            return;
        }
        if (password.equals("")) {
            JOptionPane.showMessageDialog(null, "密码不能为空");
            return;
        }



        User user = new User(userName, password,gender,address,tele);
        Connection con = null;
        try {
            con = connectMySQL.getCon();
            if (!userDao.isUserExist(con, user)) {
                int addNum = userDao.userAdd(con, user);
                if (addNum == 1) {
                    JOptionPane.showMessageDialog(null, "注册成功！");
                    this.dispose();
                    new loginFrm().setVisible(true);
                }
                else
                    JOptionPane.showMessageDialog(null, "注册失败");
            }
            else
                JOptionPane.showMessageDialog(null, "用户名存在，请重新输入！","提示",1);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                connectMySQL.closeCon(con);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }




}

