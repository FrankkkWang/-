package com.view;


import java.awt.event.ActionListener;
import java.sql.Connection;

import javax.swing.*;
import javax.swing.JOptionPane;


import com.dao.goodsDao;
import com.auxiliary.connectMySQL;


public class goodsDelFrm extends JFrame {
    connectMySQL connectMySQL = new connectMySQL();
    goodsDao goodsDao = new goodsDao();
    private JButton jb_del;
    private JTextField jtex;
    private JLabel jLabel2;
    private JButton jb_c;

    public goodsDelFrm() {
        initComponents();
        this.setLocation(320, 100);
    }

    private void initComponents() {

        //region 定义变量
        jLabel2 = new JLabel();
        jtex = new JTextField();
        jb_del = new JButton();
        jb_c = new JButton();
        //endregion

        this.setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setTitle("删除菜品");

        jLabel2.setText("菜名：");

        jb_del.setText("删除");
        jb_del.addActionListener(new ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jb_deleteActionPerformed(evt);
            }
        });

        jb_c.setText("取消");
        jb_c.addActionListener(new ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cActionPerformed(evt);
            }
        });

        GroupLayout layout = new GroupLayout(getContentPane());
        getContentPane().setLayout(layout);

        layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup() .addGap(15, 15, 15)
                        .addComponent(jLabel2)
                        .addGap(5, 5, 5)
                        .addComponent(jtex,GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                        .addGap(15, 15, 15))

                .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jb_del)
                                .addGap(10, 10, 10)
                                .addComponent(jb_c)
                                )
        );


        layout.setVerticalGroup(layout.createSequentialGroup()
                .addGap(20,20,20)
                        .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                                .addGap(55, 55, 55)
                                .addComponent(jLabel2)
                                .addGap(15, 15, 15)
                                .addComponent(jtex))
                .addGroup(layout.createParallelGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jb_del)
                        .addGap(10, 10, 10)
                        .addComponent(jb_c)

                )
        );

        pack();
    }

    //region 删除操作
    private void jb_deleteActionPerformed(java.awt.event.ActionEvent evt) {
        String name = this.jtex.getText();

        int n = JOptionPane.showConfirmDialog(null, "确定要删除吗？");
        if (n == 0) {
            Connection con = null;
            try {
                con = connectMySQL.getCon();
                int deleteNum = goodsDao.goodsDelete(con, name);
                if (deleteNum == 1) {
                    JOptionPane.showMessageDialog(null, "删除成功");
                    this.setVisible(false);
                } else
                    JOptionPane.showMessageDialog(null, "删除失败");
            } catch (Exception e) {

                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "删除失败");
            } finally {
                try {
                    connectMySQL.closeCon(con);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
    }
    //endregion

    private void cActionPerformed(java.awt.event.ActionEvent evt) {
        this.setVisible(false);
    }

}