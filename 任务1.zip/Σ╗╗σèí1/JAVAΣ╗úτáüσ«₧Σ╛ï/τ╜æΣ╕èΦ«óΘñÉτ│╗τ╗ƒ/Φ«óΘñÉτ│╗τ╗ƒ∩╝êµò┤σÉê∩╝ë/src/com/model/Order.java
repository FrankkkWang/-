package com.model;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import com.auxiliary.connectMySQL;

public class Order {

    connectMySQL connectMySQL = new connectMySQL();

    private int id;
    private String totalCost;
    private String userName;
    private String userAddress;
    private String discount;
    private String goodsName0;
    private String goodsNum0;
    private String goodsPrice0;
    private String goodsName1;
    private String goodsNum1;
    private String goodsPrice1;
    private String goodsName2;
    private String goodsNum2;
    private String goodsPrice2;
    private String goodsName3;
    private String goodsNum3;
    private String goodsPrice3;
    private String goodsName4;
    private String goodsNum4;
    private String goodsPrice4;
    private String goodsName5;
    private String goodsNum5;
    private String goodsPrice5;



    public Order() {
        super();
    }

    public Order(String userName,String userAddress,String discount,String totalCost,String gNa0,String gNu0,String gPr0,String gNa1,String gNu1,String gPr1,String gNa2,String gNu2,String gPr2,String gNa3,String gNu3,String gPr3,String gNa4,String gNu4,String gPr4,String gNa5,String gNu5,String gPr5) {
        super();
        this.userName=userName;
        this.userAddress=userAddress;
        this.discount=discount;
        this.totalCost=totalCost;
        this.goodsName0=gNa0;
        this.goodsNum0=gNu0;
        this.goodsPrice0=gPr0;
        this.goodsName1=gNa1;
        this.goodsNum1=gNu1;
        this.goodsPrice1=gPr1;
        this.goodsName2=gNa2;
        this.goodsNum2=gNu2;
        this.goodsPrice2=gPr2;
        this.goodsName3=gNa3;
        this.goodsNum3=gNu3;
        this.goodsPrice3=gPr3;
        this.goodsName4=gNa4;
        this.goodsNum4=gNu4;
        this.goodsPrice4=gPr4;
        this.goodsName5=gNa5;
        this.goodsNum5=gNu5;
        this.goodsPrice5=gPr5;
        System.out.println(this.userName);
        System.out.println(gNa0);

    }


    public int getId() {

        return id;
    }

    public void setId(int id) {

       this.id=id;
    }

    public String getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(String totalCost) {
        this.totalCost = totalCost;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(String userAddress) {
        this.userAddress = userAddress;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getGoodsName0() {
        return goodsName0;
    }

    public void setGoodsName0(String goodsName0) {
        this.goodsName0 = goodsName0;
    }

    public String getGoodsNum0() {
        return goodsNum0;
    }

    public void setGoodsNum0(String goodsNum0) {
        this.goodsNum0 = goodsNum0;
    }

    public String getGoodsPrice0() {
        return goodsPrice0;
    }

    public void setGoodsPrice0(String goodsPrice0) {
        this.goodsPrice0 = goodsPrice0;
    }

    public String getGoodsName1() {
        return goodsName1;
    }

    public void setGoodsName1(String goodsName1) {
        this.goodsName1 = goodsName1;
    }

    public String getGoodsNum1() {
        return goodsNum1;
    }

    public void setGoodsNum1(String goodsNum1) {
        this.goodsNum1 = goodsNum1;
    }

    public String getGoodsPrice1() {
        return goodsPrice1;
    }

    public void setGoodsPrice1(String goodsPrice1) {
        this.goodsPrice1 = goodsPrice1;
    }

    public String getGoodsName2() {
        return goodsName2;
    }

    public void setGoodsName2(String goodsName2) {
        this.goodsName2 = goodsName2;
    }

    public String getGoodsNum2() {
        return goodsNum2;
    }

    public void setGoodsNum2(String goodsNum2) {
        this.goodsNum2 = goodsNum2;
    }

    public String getGoodsPrice2() {
        return goodsPrice2;
    }

    public void setGoodsPrice2(String goodsPrice2) {
        this.goodsPrice2 = goodsPrice2;
    }

    public String getGoodsName3() {
        return goodsName3;
    }

    public void setGoodsName3(String goodsName3) {
        this.goodsName3 = goodsName3;
    }

    public String getGoodsNum3() {
        return goodsNum3;
    }

    public void setGoodsNum3(String goodsNum3) {
        this.goodsNum3 = goodsNum3;
    }

    public String getGoodsPrice3() {
        return goodsPrice3;
    }

    public void setGoodsPrice3(String goodsPrice3) {
        this.goodsPrice3 = goodsPrice3;
    }

    public String getGoodsName4() {
        return goodsName4;
    }

    public void setGoodsName4(String goodsName4) {
        this.goodsName4 = goodsName4;
    }

    public String getGoodsNum4() {
        return goodsNum4;
    }

    public void setGoodsNum4(String goodsNum4) {
        this.goodsNum4 = goodsNum4;
    }

    public String getGoodsPrice4() {
        return goodsPrice4;
    }

    public void setGoodsPrice4(String goodsPrice4) {
        this.goodsPrice4 = goodsPrice4;
    }

    public String getGoodsName5() {
        return goodsName5;
    }

    public void setGoodsName5(String goodsName5) {
        this.goodsName5 = goodsName5;
    }

    public String getGoodsNum5() {
        return goodsNum5;
    }

    public void setGoodsNum5(String goodsNum5) {
        this.goodsNum5 = goodsNum5;
    }

    public String getGoodsPrice5() {
        return goodsPrice5;
    }

    public void setGoodsPrice5(String goodsPrice5) {
        this.goodsPrice5 = goodsPrice5;
    }
}

