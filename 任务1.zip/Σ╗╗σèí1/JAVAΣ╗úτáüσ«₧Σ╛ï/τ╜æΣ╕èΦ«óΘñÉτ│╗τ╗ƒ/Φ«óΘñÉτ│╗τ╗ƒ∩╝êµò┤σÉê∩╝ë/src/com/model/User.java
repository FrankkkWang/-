package com.model;

public class User {
    //region 定义变量
    private int id;
    private String userName;
    private String password;
    private String gender;
    private String phoneNum;
    private String address;
    private String vip;
    private String totalCon;
    //endregion

    public User() {
        super();
    }

    public User(String userName, String password){
        super();
        this.userName = userName;
        this.password = password;
    }

    public User(String userName, String password,String gender,String address,String tele) {
        super();
        this.userName = userName;
        this.password = password;
        this.gender = gender;
        this.address = address;
        this.phoneNum = tele;
        this.vip = "否";
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getPhoneNum() {
        return phoneNum;
    }
    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getVip() {
        return vip;
    }
    public void setVip(String vip) {
        this.vip = vip;
    }
    public String getTotalCon() {
        return totalCon;
    }
    public void setTotalCon(String totalCon) {
        this.totalCon = totalCon;
    }
}


