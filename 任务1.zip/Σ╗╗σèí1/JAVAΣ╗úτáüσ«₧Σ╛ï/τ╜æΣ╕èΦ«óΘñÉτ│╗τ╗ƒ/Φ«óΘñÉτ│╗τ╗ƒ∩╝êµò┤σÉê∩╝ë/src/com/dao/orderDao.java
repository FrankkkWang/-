package com.dao;

import java.sql.*;

import com.model.Order;
import com.view.checkOrderFrm;

public class orderDao {


    public int orderAdd(Connection con, Order order) throws Exception {
        String sql = "insert into orderList(userName,userAddress,discount,totalCost,goodsName0,goodsNum0,goodsPrice0,goodsName1,goodsNum1,goodsPrice1,goodsName2,goodsNum2,goodsPrice2,goodsName3,goodsNum3,goodsPrice3,goodsName4,goodsNum4,goodsPrice4,goodsName5,goodsNum5,goodsPrice5,ensure)values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1, order.getUserName());
        pstmt.setString(2, order.getUserAddress());
        pstmt.setString(3, order.getDiscount());
        pstmt.setString(4, order.getTotalCost());
        pstmt.setString(5, order.getGoodsName0());
        pstmt.setString(6, order.getGoodsNum0());
        pstmt.setString(7, order.getGoodsPrice0());
        pstmt.setString(8, order.getGoodsName1());
        pstmt.setString(9, order.getGoodsNum1());
        pstmt.setString(10, order.getGoodsPrice1());
        pstmt.setString(11, order.getGoodsName2());
        pstmt.setString(12, order.getGoodsNum2());
        pstmt.setString(13, order.getGoodsPrice2());
        pstmt.setString(14, order.getGoodsName3());
        pstmt.setString(15, order.getGoodsNum3());
        pstmt.setString(16, order.getGoodsPrice3());
        pstmt.setString(17, order.getGoodsName4());
        pstmt.setString(18, order.getGoodsNum4());
        pstmt.setString(19, order.getGoodsPrice4());
        pstmt.setString(20, order.getGoodsName5());
        pstmt.setString(21, order.getGoodsNum5());
        pstmt.setString(22, order.getGoodsPrice5());
        pstmt.setString(23, String.valueOf('否'));

        return pstmt.executeUpdate();
    }


    public void orderDisplay(Connection con) throws Exception {
        checkOrderFrm c = new checkOrderFrm("新订单");

        try {
            Statement sql = con.createStatement();
            ResultSet res = sql.executeQuery("select *from orderList where ensure='否'");
            while (res.next()) {
                String userName = res.getString("userName");
                String userAddress = res.getString("userAddress");
                String discount = res.getString("discount");
                String totalCost = res.getString("totalCost");
                String goodsName0 = res.getString("goodsName0");
                String goodsNum0 = res.getString("goodsNum0");
                String goodsPrice0 = res.getString("goodsPrice0");
                String goodsName1 = res.getString("goodsName1");
                String goodsNum1 = res.getString("goodsNum1");
                String goodsPrice1 = res.getString("goodsPrice1");
                String goodsName2 = res.getString("goodsName2");
                String goodsNum2 = res.getString("goodsNum2");
                String goodsPrice2 = res.getString("goodsPrice2");
                String goodsName3 = res.getString("goodsName3");
                String goodsNum3 = res.getString("goodsNum3");
                String goodsPrice3 = res.getString("goodsPrice3");
                String goodsName4 = res.getString("goodsName4");
                String goodsNum4 = res.getString("goodsNum4");
                String goodsPrice4 = res.getString("goodsPrice4");
                String goodsName5 = res.getString("goodsName5");
                String goodsNum5 = res.getString("goodsNum5");
                String goodsPrice5 = res.getString("goodsPrice5");


                c.textName.setText(userName);
                c.textAddress.setText(userAddress);
                c.discountLabel.setText(discount);
                c.totalLabel.setText(totalCost);
                c.n[0].dishLabel.setText(goodsName0);
                c.n[0].numberText.setText(goodsNum0);
                c.n[0].priceLabel.setText(goodsPrice0);

                c.n[1].dishLabel.setText(goodsName1);
                c.n[1].numberText.setText(goodsNum1);
                c.n[1].priceLabel.setText(goodsPrice1);

                c.n[2].dishLabel.setText(goodsName2);
                c.n[2].numberText.setText(goodsNum2);
                c.n[2].priceLabel.setText(goodsPrice2);

                c.n[3].dishLabel.setText(goodsName3);
                c.n[3].numberText.setText(goodsNum3);
                c.n[3].priceLabel.setText(goodsPrice3);

                c.n[4].dishLabel.setText(goodsName4);
                c.n[4].numberText.setText(goodsNum4);
                c.n[4].priceLabel.setText(goodsPrice4);

                c.n[5].dishLabel.setText(goodsName5);
                c.n[5].numberText.setText(goodsNum5);
                c.n[5].priceLabel.setText(goodsPrice5);


            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    public int orderCheck(Connection con) throws Exception{


        PreparedStatement sta = null;
            sta = con.prepareStatement("update orderList set ensure=?where ensure=?");
            sta.setString(1, "是");
            sta.setString(2, "否");

            return sta.executeUpdate();

        }
    }