package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.model.Goods;


public class goodsDao {
    public int GoodsAdd(Connection con,Goods goods) throws Exception{
        String sql="insert into goods values(?,?,?,?,?)";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setInt(1,goods.getId());
        pstmt.setString(2, goods.getGoodsName());
        pstmt.setFloat(3, goods.getPrice());
        pstmt.setString(4, goods.getGoodsDesc());
        pstmt.setString(5, goods.getImageLink());
        return pstmt.executeUpdate();
    }

    public int goodsDelete(Connection con,String name) throws Exception{
        String sql="delete from goods where goodsName=?";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setString(1, name);
        return pstmt.executeUpdate();
    }
}

