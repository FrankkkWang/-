package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.model.User;
import com.view.loginFrm;

public class userDao {


    //从数据库提取用户信息
    public User login(Connection con,User user) throws Exception{
        User resultUser = null;
        //预处理（从数据库里找到用户信息）：
        String sql="select *from user where userName=? and password=?";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setString(1, user.getUserName());
        pstmt.setString(2, user.getPassword());
        //结果（将同一用户信息从数据库里赋给User类变量）：
        ResultSet rs=pstmt.executeQuery();
        if(rs.next()){
            resultUser = new User();
            resultUser.setUserName(rs.getString("userName"));
            resultUser.setPassword(rs.getString("password"));
            resultUser.setId(rs.getInt("id"));
            resultUser.setGender(rs.getString("gender"));
            resultUser.setPhoneNum(rs.getString("phoneNum"));
            resultUser.setAddress(rs.getString("address"));
            resultUser .setVip(rs.getString("vip"));
        }
        return resultUser;
    }

    //添加用户到数据库
    public static int userAdd(Connection con, User user) throws Exception{
        String sql="insert into user(userName,password,gender,phoneNum,address,vip)values(?,?,?,?,?,'否')";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setString(1, user.getUserName());
        pstmt.setString(2, user.getPassword());
        pstmt.setString(3, user.getGender());
        pstmt.setString(4, user.getPhoneNum());
        pstmt.setString(5, user.getAddress());
        return pstmt.executeUpdate();
    }

    //注册时判断数据库是否已存在该用户名
    public static boolean isUserExist(Connection con, User user) throws Exception{
        String sql="select *from user where userName=?";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setString(1, user.getUserName());
        ResultSet rs =pstmt.executeQuery();
        return rs.next();
    }

    //判断修改信息时，旧密码是否正确
    public int userModify(Connection con,User user) throws Exception{
        String sql="update user set userName=?,password=?where id=?";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setString(1, user.getUserName());
        pstmt.setString(2, user.getPassword());
        pstmt.setInt(3, user.getId());
        return pstmt.executeUpdate();
    }

    public static void vipJudge(Connection con,double m)throws Exception{

        double money=0;

        String sq = "select *from user where userName=?";
        PreparedStatement sta = con.prepareStatement(sq);
        sta.setString(1,loginFrm.currentUser.getUserName());
        ResultSet re =  sta.executeQuery();
        while(re.next()){
            String mon=re.getString("totalCon");
            money = m+Double.parseDouble(mon);
            System.out.println(money);
        }


        String sql="update user set totalCon=?,vip=? where userName=?";

        PreparedStatement pstmt=con.prepareStatement(sql);
        if(money>=500) {
            pstmt.setString(1, String.valueOf(money));
            pstmt.setString(2, "是");
            pstmt.setString(3, loginFrm.currentUser.getUserName());
            System.out.println("成为vip");

        }
        else {
            pstmt.setString(1, String.valueOf(money));
            pstmt.setString(2, "否");
            pstmt.setString(3, loginFrm.currentUser.getUserName());
            System.out.println("还不是vip");
        }


    }
}


