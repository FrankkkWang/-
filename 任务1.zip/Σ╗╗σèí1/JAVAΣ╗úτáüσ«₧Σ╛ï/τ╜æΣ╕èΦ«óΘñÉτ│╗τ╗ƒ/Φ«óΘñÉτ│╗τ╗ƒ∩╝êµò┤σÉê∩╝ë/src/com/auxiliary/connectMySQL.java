package com.auxiliary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connectMySQL {
    /**
     * 数据库路径，数据库用户姓名，密码，数据库驱动类
     */
    private static String Url = "jdbc:mysql://localhost:3306/订餐用户";
    private static String UserName = "root";
    private static String Password = "1989PaoFd";
    private static String jdbcName = "com.mysql.jdbc.Driver";

    static Connection con;

    //加载数据库驱动类，获取数据库连接
    public static Connection getCon() {
        try {
            Class.forName(jdbcName);
            System.out.println("数据库驱动加载成功");
        }catch(ClassNotFoundException e){
            e.printStackTrace();
        }

        try{
            con = DriverManager.getConnection(Url, UserName, Password);
            System.out.println("数据库连接成功");
        }catch(SQLException e){
            e.printStackTrace();
        }
        return con;
    }

    //若数据库为空，关闭数据库连接
    public static void closeCon(Connection con) throws Exception {
        if (con != null) {
            con.close();
        }
    }

    public static void main(String[] args) {
        connectMySQL dbUtil = new connectMySQL();
        dbUtil.getCon();
    }

}


